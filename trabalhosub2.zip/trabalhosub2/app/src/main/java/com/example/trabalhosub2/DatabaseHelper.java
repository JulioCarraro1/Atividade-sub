package com.example.trabalhosub2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "escola.db";
    private static final int DATABASE_VERSION = 3;


    private static final String TABLE_ALUNOS = "alunos";
    private static final String TABLE_DISCIPLINAS = "disciplinas";
    private static final String TABLE_NOTAS = "notas";


    private static final String COLUMN_ALUNO_ID = "id";
    private static final String COLUMN_ALUNO_NOME = "nome";
    private static final String COLUMN_ALUNO_RA = "ra";


    private static final String COLUMN_DISCIPLINA_ID = "id";
    private static final String COLUMN_DISCIPLINA_NOME = "nome";


    private static final String COLUMN_NOTA_ID = "id";
    private static final String COLUMN_NOTA_ALUNO_ID = "aluno_id";
    private static final String COLUMN_NOTA_DISCIPLINA_ID = "disciplina_id";
    private static final String COLUMN_NOTA_VALOR = "valor";
    private static final String COLUMN_NOTA_BIMESTRE = "bimestre";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_ALUNOS_TABLE = "CREATE TABLE " + TABLE_ALUNOS + " ("
                + COLUMN_ALUNO_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ALUNO_NOME + " TEXT NOT NULL, "
                + COLUMN_ALUNO_RA + " TEXT UNIQUE NOT NULL);";


        String CREATE_DISCIPLINAS_TABLE = "CREATE TABLE " + TABLE_DISCIPLINAS + " ("
                + COLUMN_DISCIPLINA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DISCIPLINA_NOME + " TEXT NOT NULL);";


        String CREATE_NOTAS_TABLE = "CREATE TABLE " + TABLE_NOTAS + " ("
                + COLUMN_NOTA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_NOTA_ALUNO_ID + " INTEGER, "
                + COLUMN_NOTA_DISCIPLINA_ID + " INTEGER, "
                + COLUMN_NOTA_VALOR + " REAL, "
                + COLUMN_NOTA_BIMESTRE + " INTEGER, "
                + "FOREIGN KEY(" + COLUMN_NOTA_ALUNO_ID + ") REFERENCES " + TABLE_ALUNOS + "(" + COLUMN_ALUNO_ID + "), "
                + "FOREIGN KEY(" + COLUMN_NOTA_DISCIPLINA_ID + ") REFERENCES " + TABLE_DISCIPLINAS + "(" + COLUMN_DISCIPLINA_ID + "));";

        db.execSQL(CREATE_ALUNOS_TABLE);
        db.execSQL(CREATE_DISCIPLINAS_TABLE);
        db.execSQL(CREATE_NOTAS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTAS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DISCIPLINAS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ALUNOS);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        db.execSQL("PRAGMA foreign_keys=ON;");
    }

    public long inserirAluno(String nome, String ra) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ALUNO_NOME, nome);
        values.put(COLUMN_ALUNO_RA, ra);

        long result = db.insert(TABLE_ALUNOS, null, values);
        if (result == -1) {
            Log.e("DatabaseHelper", "Erro ao inserir aluno: Nome=" + nome + ", RA=" + ra);
        } else {
            Log.d("DatabaseHelper", "Aluno inserido com sucesso: ID=" + result);
        }
        return result;
    }

    public long inserirDisciplina(String nome) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DISCIPLINA_NOME, nome);

        long result = db.insert(TABLE_DISCIPLINAS, null, values);
        if (result == -1) {
            Log.e("DatabaseHelper", "Erro ao inserir disciplina: Nome=" + nome);
        } else {
            Log.d("DatabaseHelper", "Disciplina inserida com sucesso: ID=" + result);
        }
        return result;
    }

    public long inserirNota(long alunoId, long disciplinaId, double valor, int bimestre) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOTA_ALUNO_ID, alunoId);
        values.put(COLUMN_NOTA_DISCIPLINA_ID, disciplinaId);
        values.put(COLUMN_NOTA_VALOR, valor);
        values.put(COLUMN_NOTA_BIMESTRE, bimestre);

        long result = db.insert(TABLE_NOTAS, null, values);
        if (result == -1) {
            Log.e("DatabaseHelper", "Erro ao inserir nota: AlunoID=" + alunoId + ", DisciplinaID=" + disciplinaId);
        } else {
            Log.d("DatabaseHelper", "Nota inserida com sucesso: ID=" + result);
        }
        return result;
    }

    public Cursor buscarNotasPorAluno(long alunoId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT d." + COLUMN_DISCIPLINA_NOME + ", n." + COLUMN_NOTA_VALOR + ", n." + COLUMN_NOTA_BIMESTRE +
                " FROM " + TABLE_NOTAS + " n " +
                "JOIN " + TABLE_DISCIPLINAS + " d ON n." + COLUMN_NOTA_DISCIPLINA_ID + " = d." + COLUMN_DISCIPLINA_ID +
                " WHERE n." + COLUMN_NOTA_ALUNO_ID + " = ?";
        return db.rawQuery(query, new String[]{String.valueOf(alunoId)});
    }

    public Cursor calcularMediaPorDisciplina(long disciplinaId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT AVG(" + COLUMN_NOTA_VALOR + ") as media FROM " + TABLE_NOTAS +
                " WHERE " + COLUMN_NOTA_DISCIPLINA_ID + " = ?";
        return db.rawQuery(query, new String[]{String.valueOf(disciplinaId)});
    }

    public void listarAlunos() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ALUNOS, null);
        if (cursor.moveToFirst()) {
            do {
                Log.d("DatabaseHelper", "Aluno: ID=" + cursor.getInt(0) + ", Nome=" + cursor.getString(1) + ", RA=" + cursor.getString(2));
            } while (cursor.moveToNext());
        } else {
            Log.d("DatabaseHelper", "Nenhum aluno encontrado.");
        }
        cursor.close();
    }
}
