package com.example.trabalhosub2;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class VerNotasActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ListView listViewNotas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_notas);

        dbHelper = new DatabaseHelper(this);
        listViewNotas = findViewById(R.id.listViewNotas);


        long alunoId = 1;


        Cursor cursor = dbHelper.buscarNotasPorAluno(alunoId);

        if (cursor != null && cursor.moveToFirst()) {

            String[] notas = new String[cursor.getCount()];
            int i = 0;

            do {
                String disciplina = cursor.getString(cursor.getColumnIndex("nome"));
                double nota = cursor.getDouble(cursor.getColumnIndex("valor"));
                int bimestre = cursor.getInt(cursor.getColumnIndex("bimestre"));


                notas[i] = disciplina + ": " + nota + " (Bimestre " + bimestre + ")";
                i++;
            } while (cursor.moveToNext());


            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notas);
            listViewNotas.setAdapter(adapter);
        } else {
            Toast.makeText(this, "Nenhuma nota encontrada.", Toast.LENGTH_SHORT).show();
        }
    }
}
