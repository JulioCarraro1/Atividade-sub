package com.example.trabalhosub2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText edtNomeAluno, edtRaAluno, edtDisciplina, edtNota, edtBimestre;
    private Button btnAdicionar, btnVerNotas, btnVerMedia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        edtNomeAluno = findViewById(R.id.edtNomeAluno);
        edtRaAluno = findViewById(R.id.edtRaAluno);
        edtDisciplina = findViewById(R.id.edtDisciplina);
        edtNota = findViewById(R.id.edtNota);
        edtBimestre = findViewById(R.id.edtBimestre);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        btnVerNotas = findViewById(R.id.btnVerNotas);
        btnVerMedia = findViewById(R.id.btnVerMedia);

        btnAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeAluno = edtNomeAluno.getText().toString().trim();
                String raAluno = edtRaAluno.getText().toString().trim();
                String disciplina = edtDisciplina.getText().toString().trim();
                String notaStr = edtNota.getText().toString().trim();
                String bimestreStr = edtBimestre.getText().toString().trim();

                if (!nomeAluno.isEmpty() && !raAluno.isEmpty() && !disciplina.isEmpty()
                        && !notaStr.isEmpty() && !bimestreStr.isEmpty()) {
                    double nota = Double.parseDouble(notaStr);
                    int bimestre = Integer.parseInt(bimestreStr);

                    long resultAluno = dbHelper.inserirAluno(nomeAluno, raAluno);
                    long resultDisciplina = dbHelper.inserirDisciplina(disciplina);
                    long resultNota = dbHelper.inserirNota(resultAluno, resultDisciplina, nota, bimestre);

                    if (resultNota != -1) {
                        Toast.makeText(MainActivity.this, "Nota adicionada com sucesso!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                    } else {
                        Toast.makeText(MainActivity.this, "Erro ao adicionar a nota.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnVerNotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, VerNotasActivity.class);
                startActivity(intent);
            }
        });

        btnVerMedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, VerMediaActivity.class);
                startActivity(intent);
            }
        });
    }

    private void limparCampos() {
        edtNomeAluno.setText("");
        edtRaAluno.setText("");
        edtDisciplina.setText("");
        edtNota.setText("");
        edtBimestre.setText("");
    }
}
