package com.example.trabalhosub2;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class VerMediaActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private TextView textViewMedia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_media);

        dbHelper = new DatabaseHelper(this);
        textViewMedia = findViewById(R.id.textViewMedia);


        long disciplinaId = 1;


        Cursor cursor = dbHelper.calcularMediaPorDisciplina(disciplinaId);

        if (cursor != null && cursor.moveToFirst()) {

            double media = cursor.getDouble(cursor.getColumnIndex("media"));
            textViewMedia.setText("Média: " + media);
        } else {
            Toast.makeText(this, "Nenhuma nota encontrada para calcular a média.", Toast.LENGTH_SHORT).show();
        }
    }
}
